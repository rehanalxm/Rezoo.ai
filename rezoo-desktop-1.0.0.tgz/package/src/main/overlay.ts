import { BrowserWindow, screen, app } from 'electron';
import path from 'path';

export class OverlayManager {
  private window: BrowserWindow | null = null;
  private isExpanded = true;

  constructor() {
    this.createWindow();
  }

  private createWindow() {
    const primaryDisplay = screen.getPrimaryDisplay();
    const { width, height } = primaryDisplay.workAreaSize;

    // Create comfortable assistant window (400x520) placed nicely on the right side
    this.window = new BrowserWindow({
      width: 400,
      height: 520,
      x: width - 420,
      y: height - 540,
      frame: false,
      transparent: true,
      alwaysOnTop: true,
      skipTaskbar: false,
      resizable: true,
      hasShadow: true,
      webPreferences: {
        preload: path.join(__dirname, '../preload.js'),
        contextIsolation: true,
        nodeIntegration: false,
      },
    });

    this.window.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
    this.window.setAlwaysOnTop(true, 'floating');

    // Load renderer
    const isDev = !app.isPackaged;
    if (isDev) {
      this.window.loadURL('http://localhost:5173');
    } else {
      this.window.loadFile(path.join(__dirname, '../renderer/index.html'));
    }

    this.window.show();
    this.window.focus();
  }

  public show() {
    this.window?.show();
    this.window?.focus();
  }

  public hide() {
    this.window?.hide();
  }

  public expand(width = 400, height = 520) {
    if (!this.window) return;
    this.isExpanded = true;
    const bounds = this.window.getBounds();
    this.window.setBounds({
      x: bounds.x,
      y: bounds.y,
      width,
      height,
    });
  }

  public collapse() {
    if (!this.window) return;
    this.isExpanded = false;
    const bounds = this.window.getBounds();
    this.window.setBounds({
      x: bounds.x,
      y: bounds.y,
      width: 120,
      height: 120,
    });
  }

  public toggleExpand() {
    if (this.isExpanded) {
      this.collapse();
    } else {
      this.expand();
    }
  }

  public setPosition(x: number, y: number) {
    this.window?.setPosition(x, y);
  }

  public drag(xOffset: number, yOffset: number) {
    if (!this.window) return;
    const [x, y] = this.window.getPosition();
    this.window.setPosition(x + xOffset, y + yOffset);
  }

  public getWindow() {
    return this.window;
  }

  public getIsExpanded() {
    return this.isExpanded;
  }
}
