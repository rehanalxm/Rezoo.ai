import { ipcMain } from 'electron';
import { OverlayManager } from './overlay';

export function setupIpcHandlers(overlayManager: OverlayManager) {
  ipcMain.on('overlay:toggle-expand', () => {
    overlayManager.toggleExpand();
  });

  ipcMain.on('overlay:drag', (event, x: number, y: number) => {
    overlayManager.drag(x, y);
  });

  ipcMain.on('voice:start', () => {
    // Optionally relay to backend or handle logic
  });

  ipcMain.on('voice:stop', () => {
    // Handle voice stop
  });

  ipcMain.handle('assistant:state', () => {
    // Return state
    return 'idle';
  });
}
