import React, { useState } from 'react';
import { FloatingOrb } from './components/FloatingOrb';
import { TranscriptPanel } from './components/TranscriptPanel';
import { ConfirmDialog } from './components/ConfirmDialog';
import { useAssistant } from './hooks/useAssistant';

export function App() {
  const {
    state,
    isListening,
    conversation,
    interimSpeech,
    toggleListening,
    clearChat,
    sendText,
    confirmAction,
    pendingConfirmation,
    hasPermission,
    requestMicPermission,
  } = useAssistant();

  const [isExpanded, setIsExpanded] = useState(true);

  const togglePanel = () => {
    setIsExpanded((prev) => !prev);
    if ((window as any).rezooAPI) {
      (window as any).rezooAPI.toggleExpand();
    }
  };

  const handleOrbClick = () => {
    if (!isExpanded) {
      setIsExpanded(true);
      if ((window as any).rezooAPI) {
        (window as any).rezooAPI.toggleExpand();
      }
    }
    toggleListening();
  };

  return (
    <div className={`rezoo-app ${isExpanded ? 'mode-expanded' : 'mode-minimized'}`}>
      {/* Dynamic Background Ambient Gradients */}
      <div className="bg-glow-orb bg-glow-1"></div>
      <div className="bg-glow-orb bg-glow-2"></div>

      {isExpanded ? (
        <div className="assistant-card glass-panel">
          {/* Top Integrated Orb & Header */}
          <div className="card-top-section">
            {/* Left Action: Clear Chat */}
            <div className="header-left-actions">
              {conversation.length > 0 && (
                <button onClick={clearChat} className="header-icon-btn clear-btn" title="Clear Conversation">
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <polyline points="3 6 5 6 21 6"></polyline>
                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                  </svg>
                </button>
              )}
            </div>

            <div className="header-orb-wrapper">
              <FloatingOrb
                state={state}
                onClick={handleOrbClick}
                onDoubleClick={togglePanel}
              />
            </div>

            {/* Right Action: Minimize */}
            <div className="header-right-actions">
              <button onClick={togglePanel} className="header-icon-btn minimize-btn" title="Minimize to Floating Orb">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <line x1="5" y1="12" x2="19" y2="12" />
                </svg>
              </button>
            </div>
          </div>

          {/* Mic Permission Banner if needed (especially on mobile) */}
          {hasPermission === false && (
            <div className="permission-alert">
              <span>⚠️ Mic permission required on mobile</span>
              <button onClick={() => requestMicPermission()} className="grant-btn">
                Allow Mic 🎙️
              </button>
            </div>
          )}

          {/* Transcript & Message Body */}
          <TranscriptPanel
            conversation={conversation}
            interimSpeech={interimSpeech}
            onClose={togglePanel}
            onSendMessage={sendText}
            onToggleVoice={handleOrbClick}
            state={state}
            isListening={isListening}
          />
        </div>
      ) : (
        /* Minimized Floating Bubble */
        <div className="floating-dock-widget">
          <FloatingOrb
            state={state}
            onClick={handleOrbClick}
            onDoubleClick={togglePanel}
          />
          <button onClick={togglePanel} className="expand-pill-btn">
            <span>💬 Open Rezoo</span>
          </button>
        </div>
      )}

      {/* Action Confirmation Modal */}
      {pendingConfirmation && (
        <ConfirmDialog
          confirmation={pendingConfirmation}
          onConfirm={() => confirmAction(true)}
          onCancel={() => confirmAction(false)}
        />
      )}
    </div>
  );
}
